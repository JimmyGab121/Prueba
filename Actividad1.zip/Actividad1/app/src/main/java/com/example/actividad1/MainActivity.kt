package com.example.actividad1

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //codigo para que el boton cambie de color
        var verde = false
        val color = findViewById<Button>(R.id.btncolor)

        color.setOnClickListener{
            if (verde){
                color.setBackgroundColor(Color.BLUE)
                verde = false
        }else{
            color.setBackgroundColor(Color.GREEN)
                verde = true
            }
        }

        //codigo para que cambie el texto del botón
        var flor = false
        val nombre = findViewById<Button>(R.id.btnnombre)
        val text1 = findViewById<TextView>(R.id.textflor)
        nombre.setOnClickListener {
            if (flor){
                text1.text = "Rosa"
                flor = false
            }else{
                text1.text = "Flor"
                flor = true
            }
        }

        //codigo para cambiar el texto del boton con el click
        var hola = false
        val texto = findViewById<Button>(R.id.btntext)

        texto.setOnClickListener {
            if (hola){
                texto.text = "Hola mundo"
                hola = false
            }else{
                texto.text = "Adios mundo"
                hola = true
            }
        }
    }
}